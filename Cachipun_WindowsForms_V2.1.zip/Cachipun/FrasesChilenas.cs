﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Cachipun;

/// <summary>
/// Nombres de las categorías de frases. Usar estas constantes (y no strings sueltos)
/// evita errores de tipeo.
/// </summary>
public static class Categoria
{
    // Títulos grandes del resultado
    public const string TituloGana = "titulo.gana";
    public const string TituloPierde = "titulo.pierde";
    public const string TituloEmpate = "titulo.empate";
    public const string TituloAzar = "titulo.azar";

    // Comentario de la compu bajo el resultado
    public const string DetalleGana = "detalle.gana";
    public const string DetalleGanaPrimera = "detalle.gana.primera";
    public const string DetalleGanaRacha = "detalle.gana.racha";
    public const string DetalleGanaVuelta = "detalle.gana.vuelta";
    public const string DetalleGanaRepite = "detalle.gana.repite";
    public const string DetallePierde = "detalle.pierde";
    public const string DetallePierdePrimera = "detalle.pierde.primera";
    public const string DetallePierdeRacha = "detalle.pierde.racha";
    public const string DetallePierdeCortaRacha = "detalle.pierde.cortaracha";
    public const string DetallePierdeRepite = "detalle.pierde.repite";
    public const string DetalleEmpate = "detalle.empate";
    public const string DetalleEmpatePrimera = "detalle.empate.primera";
    public const string DetalleEmpateSeguido = "detalle.empate.seguido";
    public const string DetalleAzar = "detalle.azar";

    // Mensajes de la barra de abajo
    public const string EstadoBienvenida = "estado.bienvenida";
    public const string EstadoBienvenidaMadrugada = "estado.bienvenida.madrugada";
    public const string EstadoBienvenidaManana = "estado.bienvenida.manana";
    public const string EstadoBienvenidaTarde = "estado.bienvenida.tarde";
    public const string EstadoBienvenidaNoche = "estado.bienvenida.noche";
    public const string EstadoGana = "estado.gana";
    public const string EstadoGanaRacha = "estado.gana.racha";
    public const string EstadoPierde = "estado.pierde";
    public const string EstadoPierdeRacha = "estado.pierde.racha";
    public const string EstadoEmpate = "estado.empate";
    public const string EstadoParejo = "estado.parejo";
    public const string EstadoRepite = "estado.repite";
    public const string EstadoRecord = "estado.record";
    public const string EstadoReset = "estado.reset";
    public const string EstadoModoCompu = "estado.modo.compu";
    public const string EstadoModoAzar = "estado.modo.azar";
    public const string EstadoAzar = "estado.azar";
    public const string EstadoNivelFacil = "estado.nivel.facil";
    public const string EstadoNivelNormal = "estado.nivel.normal";
    public const string EstadoNivelDificil = "estado.nivel.dificil";
    public const string EstadoPantallazo = "estado.pantallazo";
}

/// <summary>
/// Banco de frases chilenas. La compu habla como una persona: reacciona (no repite lo que ya dice
/// la regla), se acuerda de lo que pasó antes y saluda según la hora.
///
/// Cada frase es una plantilla con "marcas" entre llaves que se reemplazan según las jugadas de
/// la ronda, así el género y el plural siempre quedan bien:
///
///   {tu} / {Tu}          → "tu piedra" / "Tu piedra"        (tu jugada)
///   {mi} / {Mi}          → "mi tijera" / "Mi tijera"        (jugada de la compu)
///   {laTuya} / {LaTuya}  → "la piedra" / "el papel"         (tu jugada con artículo)
///   {laMia} / {LaMia}    → "la tijera" / "el papel"         (jugada de la compu con artículo)
///   {jugadaTu}           → "piedra"                         (tu jugada, sola)
///   {jugadaMia}          → "tijera"                         (jugada de la compu, sola)
///   {plural}             → "piedras" / "papeles" / "tijeras"
///   {esa}                → "esa piedra" / "ese papel"
///   {n}                  → un número (racha, repeticiones, etc.)
///
/// Las frases evitan adjetivos con género sobre quien juega ("cómodo", "cachado"), para que
/// funcionen igual si juega un hombre o una mujer.
/// </summary>
public sealed class FrasesChilenas
{
    private readonly Random azar;
    private readonly Dictionary<string, string> ultimaPorCategoria = new Dictionary<string, string>();

    public FrasesChilenas(Random azar)
    {
        this.azar = azar;
    }

    /// <summary>Todas las plantillas (se deja público para poder revisarlas en pruebas).</summary>
    public static IReadOnlyDictionary<string, string[]> Plantillas
    {
        get { return Banco; }
    }

    /// <summary>
    /// Elige una frase de la categoría, sin repetir la misma dos veces seguidas,
    /// y reemplaza las marcas con las jugadas indicadas.
    /// </summary>
    public string Elegir(string categoria, Jugada? tuya = null, Jugada? compu = null, int n = 0)
    {
        if (!Banco.TryGetValue(categoria, out string[]? opciones) || opciones.Length == 0)
            return string.Empty;

        string plantilla = opciones[0];

        if (opciones.Length > 1)
        {
            ultimaPorCategoria.TryGetValue(categoria, out string? anterior);
            string[] candidatas = anterior == null
                ? opciones
                : opciones.Where(o => o != anterior).ToArray();

            if (candidatas.Length == 0) candidatas = opciones;

            plantilla = candidatas[azar.Next(candidatas.Length)];
            ultimaPorCategoria[categoria] = plantilla;
        }

        return Armar(plantilla, tuya, compu, n);
    }

    /// <summary>
    /// Saludo de bienvenida según la hora del día (0 a 23). De vez en cuando usa uno general,
    /// para que no suene siempre igual.
    /// </summary>
    public string Saludo(int hora)
    {
        if (azar.NextDouble() < 0.30)
            return Elegir(Categoria.EstadoBienvenida);

        string categoria;
        if (hora < 6) categoria = Categoria.EstadoBienvenidaMadrugada;
        else if (hora < 12) categoria = Categoria.EstadoBienvenidaManana;
        else if (hora < 20) categoria = Categoria.EstadoBienvenidaTarde;
        else categoria = Categoria.EstadoBienvenidaNoche;

        return Elegir(categoria);
    }

    /// <summary>Frase especial cuando se llega a cierta cantidad de rondas (null si no toca ninguna).</summary>
    public string? Hito(int rondas)
    {
        return Hitos.TryGetValue(rondas, out string? frase) ? frase : null;
    }

    public void Reiniciar()
    {
        ultimaPorCategoria.Clear();
    }

    private static string Armar(string plantilla, Jugada? tuya, Jugada? compu, int n)
    {
        string r = plantilla;

        if (tuya is Jugada t)
        {
            r = r.Replace("{Tu}", "Tu " + t.Nombre())
                 .Replace("{tu}", "tu " + t.Nombre())
                 .Replace("{LaTuya}", Mayuscula(t.ConArticulo()))
                 .Replace("{laTuya}", t.ConArticulo())
                 .Replace("{jugadaTu}", t.Nombre())
                 .Replace("{plural}", t.Plural())
                 .Replace("{esa}", t.Esa());
        }

        if (compu is Jugada c)
        {
            r = r.Replace("{Mi}", "Mi " + c.Nombre())
                 .Replace("{mi}", "mi " + c.Nombre())
                 .Replace("{LaMia}", Mayuscula(c.ConArticulo()))
                 .Replace("{laMia}", c.ConArticulo())
                 .Replace("{jugadaMia}", c.Nombre());
        }

        return r.Replace("{n}", n.ToString());
    }

    private static string Mayuscula(string texto)
    {
        return char.ToUpper(texto[0]) + texto.Substring(1);
    }

    private static readonly Dictionary<int, string> Hitos = new Dictionary<int, string>
    {
        [5] = "Cinco rondas y seguimos vivos. Buen comienzo.",
        [10] = "¡Ya van 10 rondas! Esto se está poniendo serio, ¿cachai?",
        [20] = "20 rondas. Ya te conozco mejor que tu familia.",
        [25] = "25 rondas... ¿no teníai tareas pendientes, po?",
        [50] = "50 rondas. Ya somos casi amigos.",
        [100] = "100 rondas. Oficialmente, leyenda del cachipún."
    };

    private static readonly Dictionary<string, string[]> Banco = new Dictionary<string, string[]>
    {
        // ------------------------------------------------------------------ TÍTULOS
        [Categoria.TituloGana] = new[]
        {
            "¡Ganaste!",
            "¡Sipo, ganaste!",
            "¡Ahí está!",
            "¡Esa estuvo filete!",
            "¡Bacán!",
            "¡Te la mandaste!",
            "¡Punto pa' ti!",
            "¡Nooo, me ganaste!"
        },
        [Categoria.TituloPierde] = new[]
        {
            "¡Perdiste!",
            "¡Ahí te pillé!",
            "Esta fue mía",
            "¡Chuta, perdiste!",
            "¡Punto pa' mí!",
            "Uy, esa no era",
            "Me salió, po"
        },
        [Categoria.TituloEmpate] = new[]
        {
            "¡Empate!",
            "¡Quedamos a mano!",
            "¡Pensamos lo mismo!",
            "¡Empate, po!",
            "¡Parejito!",
            "Mmm, igualitos"
        },
        [Categoria.TituloAzar] = new[]
        {
            "¡Te tocó {laTuya}!",
            "¡Sale {laTuya}!",
            "¡Va {laTuya}!",
            "¡Tírate {laTuya}!",
            "Yo me iría con {laTuya}"
        },

        // ------------------------------------------------------------------ DETALLE: GANAS
        [Categoria.DetalleGana] = new[]
        {
            "Mira tú, me pillaste. Juraba que ibas a tirar otra cosa.",
            "Ay, no. {Tu} le pasó por encima a {mi}. Bien jugado, igual.",
            "Ya, ya, punto pa' ti. Que no se te suba a la cabeza, ¿ya?",
            "Justo tiré {jugadaMia}... qué mala pata la mía.",
            "Me ganaste limpiecito. Voy a tener que ponerme las pilas.",
            "¡Oye, qué buena! Esa no la vi venir.",
            "Bueno, bueno. {Tu} le ganó a {mi} y yo no tengo na que decir.",
            "Se te dio nomás... pero se te dio."
        },
        [Categoria.DetalleGanaPrimera] = new[]
        {
            "¡Y se rompió el hielo! Primera ronda y ya me ganaste.",
            "Primera ronda y me ganai. Qué manera de partir.",
            "¿Suerte de principiante? Ya veremos."
        },
        [Categoria.DetalleGanaRacha] = new[]
        {
            "¡Van {n} seguidas! Esto ya no es suerte, ¿o sí?",
            "{n} al hilo. Oye, ¿tú cachai mis jugadas o qué?",
            "Ya po, ¿hasta cuándo? {n} seguidas y yo aquí, haciendo el ridículo.",
            "{n} victorias seguidas... Me tinca que hoy no es mi día.",
            "Estai on fire: {n} al hilo. Alguien tiene que pararte.",
            "Nooo, otra más. Van {n}. Dame una oportunidad, po."
        },
        [Categoria.DetalleGanaVuelta] = new[]
        {
            "¡Ahí está la vuelta! Eso es no achuncharse.",
            "Te desquitaste. Se nota que no te gusta perder.",
            "Así me gusta: caíste y te paraste, sin llorar.",
            "Revancha cobrada: {tu} le pasó la aplanadora a {mi}.",
            "Ya, ya, se te dio la vuelta. Pero no te confíes, ¿ya?"
        },
        [Categoria.DetalleGanaRepite] = new[]
        {
            "Tirai {laTuya} otra vez y te vuelve a funcionar. Qué porfiada la suerte.",
            "¿{LaTuya} de nuevo? Y me ganó de nuevo. Ya me cansé de ese truco.",
            "Con {laTuya} otra vez... y me gana. Voy a tener que cambiar yo."
        },

        // ------------------------------------------------------------------ DETALLE: PIERDES
        [Categoria.DetallePierde] = new[]
        {
            "Esta fue mía. {Mi} le ganó a {tu}, sin drama.",
            "Ahí te pillé: tiré {jugadaMia} y tú {jugadaTu}. Mala pata, nomás.",
            "Tranqui, es solo una ronda. Ya vendrá la revancha.",
            "Uy, esa no era. {Mi} le pasó por encima a {tu}.",
            "¡Qué penca! Si hasta me da cosa ganarte así.",
            "No hay caso: {laMia} le gana a {tu}. Tírate otra, po.",
            "Mmm, olía a {jugadaTu} desde lejos.",
            "Perdón, ¿era tu turno de ganar? Uy."
        },
        [Categoria.DetallePierdePrimera] = new[]
        {
            "Primera ronda, primer punto pa' mí. Buen comienzo.",
            "Así partimos, po. Ya vendrá tu momento.",
            "No te desanimís, recién estamos calentando."
        },
        [Categoria.DetallePierdeRacha] = new[]
        {
            "Van {n} pa' mí... Tranqui, cambia el chip y tírate otra cosa.",
            "¿{n} seguidas? Cambia de jugada, po, que ya te caché el estilo.",
            "Esto ya no es suerte, es estrategia, jaja. No te piquís, ¿ya?",
            "{n} derrotas al hilo. Respira hondo y tírate algo distinto.",
            "Oye, te lo digo con cariño: algo tenís que cambiar."
        },
        [Categoria.DetallePierdeCortaRacha] = new[]
        {
            "Ahí se cortó la racha. Igual venías súper bien.",
            "¡Te corté la racha! No me odies.",
            "Bueno, no se puede ganar siempre. {Mi} frenó a {tu}.",
            "Se acabó lo bueno, po. Ahora me toca a mí."
        },
        [Categoria.DetallePierdeRepite] = new[]
        {
            "¿{LaTuya} otra vez? Ya te tenía el dato, po.",
            "Otra vez {laTuya}, y otra vez te gano. Cambia el disco, po.",
            "Con {laTuya} no vai a ningún lado. Pruébate otra."
        },

        // ------------------------------------------------------------------ DETALLE: EMPATES
        [Categoria.DetalleEmpate] = new[]
        {
            "Los dos tiramos {jugadaTu}. ¿Nos leímos la mente o qué?",
            "Misma jugada: {jugadaTu}. Está súper parejo esto.",
            "Nos copiamos: los dos {jugadaTu}. Desempate al tiro, po.",
            "{Tu} contra {mi}: exactamente lo mismo. Nadie gana, nadie pierde.",
            "¡Pensamos lo mismo! {LaTuya} por los dos lados.",
            "Empate con {laTuya}. Esto se está poniendo bueno, ¿cachai?",
            "Mmm, eso fue telepatía. O casualidad. O las dos.",
            "Ni pa' ti ni pa' mí. Otra vez, ¿ya?"
        },
        [Categoria.DetalleEmpatePrimera] = new[]
        {
            "Primera ronda y ya empatamos. Mal que mal, nos entendemos.",
            "Partimos igualados. Eso me gusta."
        },
        [Categoria.DetalleEmpateSeguido] = new[]
        {
            "{n} empates seguidos... Esto ya es telepatía.",
            "Otra vez empate. ¿Estamos conectados o qué?",
            "Ya van {n} empates al hilo. Alguien tiene que cambiar de jugada, po.",
            "{n} empates... Yo creo que nos conocemos demasiado."
        },

        // ------------------------------------------------------------------ DETALLE: MODO AZAR
        [Categoria.DetalleAzar] = new[]
        {
            "Si no te convence, pídeme otra, po.",
            "Si sale mal, no me culpís, ¿ya?",
            "El destino habló. Yo soy solo el mensajero.",
            "¡Y no vale cambiar después!",
            "Con {laTuya} no te puede ir tan mal... ¿o sí?"
        },

        // ------------------------------------------------------------------ BARRA DE ABAJO: BIENVENIDA
        [Categoria.EstadoBienvenida] = new[]
        {
            "Acomódate nomás, que venimos a pasarlo chancho. ¡Ya, partamos!",
            "Una partidita rápida, ¿ya? Escoge tu jugada y partimos.",
            "Atajos: 1, 2 y 3 para jugar. Ahora, ¡a echarse un cachipún!"
        },
        [Categoria.EstadoBienvenidaMadrugada] = new[]
        {
            "¿Despierto a esta hora? Ya, un cachipún rápido y a dormir.",
            "Madrugada y cachipún... qué combinación. Partamos."
        },
        [Categoria.EstadoBienvenidaManana] = new[]
        {
            "Buenos días. Un cachipún con el café, ¿ya?",
            "Buen día pa' echarse una partida. ¡Partamos!"
        },
        [Categoria.EstadoBienvenidaTarde] = new[]
        {
            "Buenas tardes. Una partidita pa' espantar el sueño de la tarde.",
            "Tarde tranqui, partida tranqui. Cuando querai."
        },
        [Categoria.EstadoBienvenidaNoche] = new[]
        {
            "Buenas noches. Un cachipún antes de dormir, ¿o qué?",
            "Noche de cachipún. Acomódate nomás."
        },

        // ------------------------------------------------------------------ BARRA DE ABAJO: DURANTE LA PARTIDA
        [Categoria.EstadoGana] = new[]
        {
            "Bacán. A ver si te dura la racha.",
            "Punto pa' ti; ya me dieron ganas de revancha.",
            "Va bien la cosa, sigue así nomás.",
            "Disfrútalo nomás, ¿cachai?",
            "Buena esa, pero ahora no te durmai.",
            "Jaja, me estai poniendo nervios."
        },
        [Categoria.EstadoGanaRacha] = new[]
        {
            "Estai imparable. ¿Quién te para?",
            "Ya po, dame una oportunidad, que me estai dejando en vergüenza.",
            "No te agrandís todavía... aunque lo estai haciendo súper.",
            "Racha de {n}. Me tinca que tengo que cambiar la estrategia.",
            "Alguien llame a los bomberos: acá hay una racha en llamas."
        },
        [Categoria.EstadoPierde] = new[]
        {
            "Tranqui, es una ronda nomás. ¿Revancha?",
            "No pasa na; prueba otra jugada.",
            "Me llevé este punto, pero la partida sigue abierta.",
            "Ya, sacúdete y vamos de nuevo.",
            "Así es el cachipún: hoy tú, mañana yo.",
            "Pa' la próxima se te da, ya vai a ver."
        },
        [Categoria.EstadoPierdeRacha] = new[]
        {
            "Ya, respiremos. Cambia la jugada y veamos qué pasa.",
            "No te piquís; a veces toca remontar. ¿Otra?",
            "Si querís un respiro, bájale el nivel a la compu ahí a la derecha.",
            "Ponte las pilas, que todavía se puede dar vuelta.",
            "Te regalaría una, pero no sé perder a propósito."
        },
        [Categoria.EstadoEmpate] = new[]
        {
            "Ya, otra más; esta ronda no cuenta pa' ninguno.",
            "Estamos leyendo la misma mente, parece.",
            "Ni pa' ti ni pa' mí. La próxima sí que sí.",
            "Seguimos igualados, queda harto juego.",
            "Otra, po. Que alguien se anime a ganar."
        },
        [Categoria.EstadoParejo] = new[]
        {
            "Vamos {n} a {n}. Más parejo que final de campeonato.",
            "Qué pelea: {n} a {n}.",
            "Empatados en {n}... esto se decide en la próxima."
        },
        [Categoria.EstadoRepite] = new[]
        {
            "Van {n} veces con {laTuya}... ya te estoy cachando el estilo 👀",
            "Otra vez {laTuya}. ¿Es tu jugada favorita o me estai tendiendo una trampa?",
            "Te gusta {laTuya}, ¿ah? Voy a tener que andar con ojo.",
            "{n} {plural} al hilo. ¿Y si probamos con otra cosa?",
            "Mmm, ¿y si pruebas otra jugada? Digo, por variar."
        },
        [Categoria.EstadoRecord] = new[]
        {
            "¡Nueva mejor racha: {n}! Anótalo en la pizarra.",
            "¡Récord! {n} seguidas, tu mejor racha hasta ahora.",
            "¡{n} al hilo! Nunca habías llegado tan lejos."
        },
        [Categoria.EstadoReset] = new[]
        {
            "Partida nueva, po. ¡Ya, aperra sin miedo!",
            "Todo en cero. Borrón y cuenta nueva.",
            "Partimos de cero. Esta vez gano yo... o tú, ¿quién sabe?",
            "Como si nada hubiera pasado. Yo igual me acuerdo, eh."
        },
        [Categoria.EstadoModoCompu] = new[]
        {
            "Modo compu: yo juego y tú tirai. ¡A ver quién manda!",
            "Contra la compu otra vez. ¡Ya, aperra!"
        },
        [Categoria.EstadoModoAzar] = new[]
        {
            "Modo azar: yo te digo qué tirar y tú lo tirai nomás.",
            "Modo azar: confía en el destino... o en mí."
        },
        [Categoria.EstadoAzar] = new[]
        {
            "Cuando querís otra, aprieta el botón de nuevo.",
            "Anda con confianza, que el azar no se equivoca... ¿o sí?",
            "Tírala nomás: la suerte ya está echada."
        },
        [Categoria.EstadoNivelFacil] = new[]
        {
            "Nivel fácil: tiro lo primero que se me ocurra. Relax.",
            "Modo fácil: ni yo sé qué voy a tirar."
        },
        [Categoria.EstadoNivelNormal] = new[]
        {
            "Nivel normal: ojo que me voy a fijar en tu última jugada.",
            "Normal: ya empiezo a mirarte de reojo."
        },
        [Categoria.EstadoNivelDificil] = new[]
        {
            "Nivel difícil: ya te estoy cachando los hábitos. Ahora sí que sí.",
            "Difícil: me aprendo tus mañas... y no las suelto."
        },
        [Categoria.EstadoPantallazo] = new[]
        {
            "¡Listoco! Pantallazo guardado en el Escritorio, carpeta PantallazosCachipun.",
            "Pantallazo listo, en el Escritorio. Ahora a presumir con los amigos."
        }
    };
}
